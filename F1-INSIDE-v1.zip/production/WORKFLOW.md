# Flujo de producción

1. **Selección:** elegir una pregunta concreta y evaluar interés, fuentes y recursos legales.
2. **Investigación:** recopilar fuentes primarias y contraste; completar ficha de verificación.
3. **Brief:** definir promesa, audiencia, formato y enfoque.
4. **Guion:** escribir con voz propia; separar hechos y análisis.
5. **Revisión factual:** verificar nombres, fechas, cifras, citas y contexto.
6. **Revisión de derechos:** comprobar cada imagen, vídeo, música, fuente tipográfica y gráfico.
7. **Producción:** grabar voz, crear gráficos originales, editar y subtitular.
8. **Control de calidad:** audio, ortografía, subtítulos, ritmo, fuentes y derechos.
9. **Empaque:** título, miniatura, descripción y capítulos si aplican.
10. **Publicación:** revisar configuración, audiencia, visibilidad y enlaces.
11. **Aprendizaje:** registrar métricas a 24 h, 7 días y 28 días cuando haya datos.

## Regla de publicación
No publicar si hay afirmaciones centrales sin verificar, recursos sin derechos claros o errores materiales pendientes.
