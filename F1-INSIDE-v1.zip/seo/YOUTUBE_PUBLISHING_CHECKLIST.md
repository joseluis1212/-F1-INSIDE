# SEO y publicación en YouTube

## Antes de publicar
- [ ] Título claro, específico y fiel al contenido.
- [ ] Miniatura legible en móvil y con derechos verificados.
- [ ] Primeras líneas de descripción explican el valor del vídeo.
- [ ] Fuentes y créditos relevantes incluidos.
- [ ] Capítulos cuando mejoren navegación.
- [ ] Subtítulos revisados.
- [ ] Playlist adecuada.
- [ ] Pantallas finales y tarjetas solo si aportan valor.
- [ ] Revisar audiencia, visibilidad y fecha de publicación.

## Descripción — plantilla
En este vídeo analizamos [tema] y explicamos [promesa concreta].

**Fuentes y lecturas:**
- [Fuente 1]
- [Fuente 2]

F1 INSIDE es un medio independiente y no está afiliado a Formula 1, FIA ni a equipos.

## Etiquetas
Usar solo términos relevantes. Las etiquetas tienen un papel limitado; priorizar claridad del tema, título, miniatura y satisfacción del espectador.
