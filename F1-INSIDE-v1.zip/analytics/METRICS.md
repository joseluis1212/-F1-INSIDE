# Analítica y aprendizaje

Registrar por pieza:

| Fecha | ID | Formato | Tema | Impresiones | CTR | Vistas | Duración media | Retención | Subs. | Observaciones |
|---|---|---|---|---:|---:|---:|---:|---:|---:|---|

## Momentos de revisión
- 24 horas: señales iniciales, sin sacar conclusiones precipitadas.
- 7 días: comparar con piezas del mismo formato.
- 28 días: observar rendimiento más estable.

## Preguntas
- ¿Qué promesa atrajo clics?
- ¿En qué momento se fue la audiencia?
- ¿Qué temas generan espectadores recurrentes?
- ¿Qué formato es sostenible producir?
- ¿Qué cambiaríamos en una sola variable para el siguiente experimento?

No comparar Shorts y vídeos largos como si tuvieran el mismo comportamiento.
