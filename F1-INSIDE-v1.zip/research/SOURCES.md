# Fuentes de investigación

Priorizar fuentes primarias y oficiales. Consultar siempre la página concreta y registrar fecha/hora de acceso.

## Fuentes primarias
- Formula 1: https://www.formula1.com/
- FIA: https://www.fia.com/
- Comunicados oficiales de equipos y pilotos: localizar en sus sitios oficiales verificados.
- Documentos, reglamentos y decisiones FIA: https://www.fia.com/regulation

## Fuentes secundarias
Usar medios periodísticos reconocidos para contexto y contraste. No depender de una única publicación para afirmaciones controvertidas.

## Registro obligatorio
Para cada dato central, guardar:
- Afirmación exacta.
- Fuente y URL.
- Autor/organización.
- Fecha de publicación.
- Fecha de consulta.
- Cita o fragmento de apoyo (breve).
- Nivel: confirmado / reportado / no confirmado.
- Segunda fuente, cuando corresponda.

No tratar publicaciones de redes sociales sin verificación como evidencia suficiente.
