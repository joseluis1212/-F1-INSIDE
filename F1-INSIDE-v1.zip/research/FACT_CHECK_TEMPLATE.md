# Ficha de verificación

- Pieza:
- Responsable:
- Fecha de revisión:
- Fecha/hora de corte informativo:

| Afirmación | Fuente primaria | Fuente de contraste | Estado | Nota |
|---|---|---|---|---|
| | | | Pendiente | |

## Control
- [ ] Nombres, fechas, cifras y resultados verificados.
- [ ] Citas comprobadas en su contexto.
- [ ] Rumores etiquetados como tales.
- [ ] Datos históricos contrastados.
- [ ] No se infieren motivaciones sin evidencia.
- [ ] Cada dato central tiene fuente trazable.
