# Banco de ideas editoriales

| ID | Idea / pregunta | Pilar | Actualidad | Fuentes iniciales | Estado |
|---|---|---|---|---|---|
| F1-001 | ¿Qué hace realmente un director de carrera durante un GP? | Análisis | Evergreen | FIA, reglamento | Pendiente |
| F1-002 | Cómo se decide una parada en boxes | Análisis | Evergreen | F1, equipos | Pendiente |
| F1-003 | Una rivalidad que cambió una temporada | Historias | Evergreen | Archivos y entrevistas autorizadas | Pendiente |

Añadir ideas como preguntas concretas, no como títulos definitivos. Validar interés, disponibilidad de fuentes y derechos antes de producir.
