# Plan del proyecto — F1 INSIDE

## Objetivo de la versión 1.0
Disponer de un proceso repetible para investigar, escribir, producir, revisar y medir vídeos originales sobre Fórmula 1.

## Público inicial
Personas hispanohablantes que siguen la F1 y quieren entender no solo qué pasó, sino por qué importa. No asumir edad, país ni nivel de conocimiento: validar con analítica y comentarios.

## Posicionamiento
**La Fórmula 1 explicada desde dentro: historias, decisiones y estrategia detrás del espectáculo.**

## Alcance v1.0
- Identidad editorial y visual documentada.
- Fuentes de investigación y ficha de verificación.
- Plantillas de vídeo largo y Shorts.
- Proceso de producción y control de calidad.
- SEO y calendario editorial.
- Registro de métricas y experimentos.

## Fuera de alcance inicial
- Aplicación web propia.
- Scraping de sitios o redes.
- Publicación automática sin revisión humana.
- Compra de material audiovisual.
- Automatizaciones complejas o servicios pagos.

## Plan de lanzamiento de 7 días
| Día | Entregable |
|---|---|
| 1 | Definir marca, audiencia y promesa editorial |
| 2 | Investigar tres historias y validar fuentes |
| 3 | Elegir una historia y redactar el guion |
| 4 | Verificar datos, derechos y narración |
| 5 | Grabar voz y montar primer corte |
| 6 | Crear miniatura, título y descripción |
| 7 | Publicar o dejar programado; registrar línea base |

## Criterio de salida
La v1.0 está lista cuando un vídeo puede pasar desde idea hasta publicación usando las plantillas, con fuentes, revisión factual y revisión de derechos documentadas.

## Indicadores iniciales
- Piezas publicadas por semana.
- Impresiones y tasa de clics (CTR).
- Retención media y duración media de visualización.
- Espectadores recurrentes.
- Suscriptores obtenidos por pieza.
- Comentarios sustantivos y temas solicitados.

No fijar metas arbitrarias antes de tener una línea base.
