# Política de derechos, marcas y atribución

F1 INSIDE es un proyecto independiente y no está afiliado ni respaldado por Formula 1, FIA, equipos, pilotos o promotores.

## Material audiovisual
- Priorizar grabaciones propias, gráficos originales, animaciones propias y material con licencia compatible.
- No descargar, reutilizar ni editar retransmisiones, onboard, radio de equipo, clips oficiales o fotografías protegidas sin autorización o licencia.
- Dar crédito no sustituye el permiso.
- No asumir que un uso es legal por ser breve, educativo, transformativo o estar disponible en redes.
- Las excepciones legales dependen de la jurisdicción y del caso; solicitar asesoramiento cuando exista duda.

## Marcas y nombres
Usar nombres de pilotos, equipos, campeonatos y marcas solo para identificar el tema de forma veraz. No imitar logotipos oficiales ni crear una apariencia que sugiera afiliación.

## Música, tipografías y recursos
Registrar autor, URL/licencia, condiciones, fecha de descarga y prueba de permiso. Verificar que la licencia cubra uso comercial y YouTube.

## Registro de derechos
Cada pieza debe incluir una lista de recursos visuales y sonoros, origen, licencia/permiso y restricciones.

## YouTube
Cumplir las políticas vigentes de copyright, monetización y contenido reutilizado. La elegibilidad para monetización no está garantizada por el carácter original del guion: también importa el valor añadido de la pieza completa.
