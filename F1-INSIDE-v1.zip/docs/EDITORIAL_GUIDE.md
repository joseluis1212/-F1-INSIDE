# Manual editorial

## Voz
Clara, inteligente, dinámica y accesible. Dramática cuando los hechos lo justifican; nunca sensacionalista. Explicar términos técnicos en lenguaje común.

## Reglas
1. La noticia no es el análisis: identificar ambos.
2. Fechar la información y registrar cuándo se consultó.
3. Confirmar afirmaciones importantes con fuentes primarias siempre que sea posible.
4. No presentar rumores como hechos.
5. No atribuir citas sin fuente original y contexto.
6. Diferenciar datos oficiales, reportes periodísticos, opiniones y especulación.
7. Corregir errores con transparencia.

## Estructura narrativa sugerida
- Gancho: pregunta, conflicto o dato verificable.
- Contexto: qué necesita saber la audiencia.
- Desarrollo: evidencia, explicación y consecuencias.
- Giro o hallazgo: qué cambia la interpretación.
- Cierre: conclusión y pregunta genuina para la comunidad.

## Tratamiento de actualidad
Incluir fecha, hora y zona horaria cuando el momento sea relevante. En noticias en desarrollo, indicar qué se sabe, qué no se sabe y qué podría cambiar.

## Rumores y fichajes
Solo cubrir si hay interés editorial y fuentes identificables. Etiquetar como rumor o reporte; indicar nivel de confirmación y evitar convertir especulación en titular factual.

## Lenguaje
Evitar insultos, ataques personales, afirmaciones difamatorias y conclusiones sobre intenciones sin evidencia.
