# Identidad visual — F1 INSIDE

## Dirección creativa
Editorial de automovilismo contemporáneo: precisión, velocidad y análisis. Evitar copiar la identidad visual de Formula 1 o de equipos.

## Paleta sugerida
- Carbón: `#111318` — fondos.
- Blanco cálido: `#F4F1EA` — texto principal.
- Rojo señal: `#D62828` — acento puntual, no imitación de marca oficial.
- Gris técnico: `#8B929C` — metadatos.
- Azul acero: `#35495E` — gráficos secundarios.

## Tipografía
Usar tipografías con licencia adecuada para uso comercial. Preferir una sans serif condensada para titulares y una sans serif muy legible para cuerpo.

## Composición
- Contraste alto.
- Un foco visual por miniatura.
- Máximo 3–5 palabras en texto de miniatura.
- No usar logos, trofeos, imágenes de pilotos o coches sin derechos.
- Mantener sistema consistente, no repetir la misma plantilla sin adaptación.

## Logo
Crear un wordmark original “F1 INSIDE”. No usar el logotipo oficial de Formula 1 ni una variación que pueda confundirse con él.
