# Guía de miniaturas

## Principios
- Una idea visual y una promesa editorial por miniatura.
- Legibilidad en móvil.
- Contraste y jerarquía claros.
- No duplicar exactamente el título.
- No usar imágenes de retransmisión ni fotografías sin licencia.

## Prueba antes de publicar
1. Reducir la miniatura al tamaño de móvil.
2. Comprobar que el foco se entiende en 1 segundo.
3. Verificar que texto y título no prometen cosas distintas.
4. Revisar derechos de cada elemento.
5. Evitar falsas citas, resultados o escenas.
