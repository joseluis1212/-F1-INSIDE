# Guion — YouTube Short

- Tema:
- Una sola idea:
- Fuente(s):
- Duración objetivo: 25–60 s

## Guion
**0–3 s — Gancho:** pregunta o hecho verificable.
**3–15 s — Contexto:** lo mínimo necesario.
**15–45 s — Explicación:** una idea clara y concreta.
**45–60 s — Cierre:** conclusión o pregunta para la audiencia.

## Revisión
- [ ] Se entiende sin contexto previo.
- [ ] Una sola idea.
- [ ] Subtítulos legibles.
- [ ] No depende de clips protegidos sin permiso.
- [ ] Fuente y fecha verificadas.
