# Guion — vídeo largo

- Título de trabajo:
- Pregunta central:
- Pilar:
- Audiencia:
- Duración objetivo:
- Fecha de corte:
- Fuentes: enlazar ficha de verificación.

## 1. Gancho (0:00–0:20)
Abrir con el conflicto o la pregunta. No exagerar ni prometer algo que el vídeo no demuestra.

## 2. Contexto (0:20–1:30)
Explicar quién, cuándo, dónde y por qué importa.

## 3. Desarrollo
Bloques breves. Cada bloque debe aportar evidencia, explicación o tensión narrativa.

## 4. Hallazgo / consecuencia
¿Qué revela la historia? ¿Qué cambió o qué puede aprender la audiencia?

## 5. Cierre
Conclusión, límites de lo que se sabe y pregunta específica para comentarios.

## Notas de producción
- Voz:
- Visuales propios/licenciados:
- Gráficos:
- Música autorizada:
- Derechos verificados: Sí/No
