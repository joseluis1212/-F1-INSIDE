# Brief de contenido

- ID:
- Fecha:
- Responsable:
- Formato:
- Pilar:
- Tema:
- Audiencia:
- Promesa al espectador:
- Pregunta que responde:
- Por qué ahora:
- Fuentes:
- Recursos visuales autorizados:
- Riesgos / incertidumbres:
- Título provisional:
- CTA:
- Estado: idea / investigación / guion / producción / revisión / publicado
