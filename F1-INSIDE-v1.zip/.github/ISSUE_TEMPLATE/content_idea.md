---
name: Nueva idea de contenido
about: Proponer una historia, análisis o noticia para F1 INSIDE
title: "[IDEA] "
labels: content
assignees: ""
---

## Pregunta central
## Pilar editorial
## Por qué le interesa a la audiencia
## Fuentes iniciales
## Riesgos / datos por verificar
## Formato sugerido
