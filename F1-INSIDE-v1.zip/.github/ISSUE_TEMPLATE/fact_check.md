---
name: Revisión factual
about: Registrar una afirmación que necesita verificación
title: "[FACT-CHECK] "
labels: research
assignees: ""
---

## Afirmación
## Fuente primaria
## Fuente de contraste
## Estado
## Decisión editorial
