# Plan de monetización

## Etapa 1 — Validar
Prioridad: consistencia, calidad, audiencia y confianza. No contar ingresos antes de tenerlos.

## Etapa 2 — Elegibilidad
Consultar siempre los requisitos actuales del Programa de socios de YouTube en la ayuda oficial. Los umbrales y funciones pueden cambiar por país y fecha.

## Etapa 3 — Vías complementarias
- Patrocinios alineados con la audiencia y claramente identificados.
- Afiliación transparente, solo productos relevantes y con divulgación.
- Membresías o comunidad cuando exista demanda real.
- Productos editoriales originales (guías, newsletters, informes) cuando haya audiencia suficiente.

## Principios
No recomendar apuestas, productos dudosos ni servicios que dañen la confianza. Divulgar relaciones comerciales. No comprar seguidores, vistas ni interacciones.
