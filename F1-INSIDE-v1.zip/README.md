# F1 INSIDE

**Medio digital independiente en español sobre Fórmula 1.** Historias, análisis, contexto y actualidad explicados con una voz propia.

> Proyecto editorial independiente. No está afiliado, patrocinado ni respaldado por Formula 1, FIA, equipos o pilotos.

## Misión
Convertir la complejidad, la historia y el drama deportivo de la Fórmula 1 en contenido original, riguroso, visual y entretenido para audiencias hispanohablantes.

## Pilares editoriales
1. **Historias:** pilotos, rivalidades, decisiones y momentos históricos.
2. **Análisis:** estrategia, rendimiento, reglamento y tecnología explicados.
3. **Actualidad:** noticias verificadas con contexto y atribución.
4. **Curiosidades:** datos y explicaciones breves que despiertan interés.

## Formatos
- Vídeo principal: 6–12 minutos como formato inicial de prueba.
- Shorts: 25–60 segundos, una idea por pieza.
- Comunidad: encuestas, preguntas y seguimiento de temas.

## Estructura
- `docs/`: estrategia, guías y políticas.
- `research/`: fuentes, ideas y fichas de investigación.
- `content/`: guiones y piezas publicadas.
- `branding/`: identidad y miniaturas.
- `production/`: proceso de producción.
- `seo/`: títulos, descripciones y publicación.
- `analytics/`: métricas y experimentos.
- `monetization/`: vías de ingresos.

## Empezar
1. Leer `docs/PROJECT_PLAN.md`.
2. Aplicar `docs/EDITORIAL_GUIDE.md` y `docs/COPYRIGHT_POLICY.md`.
3. Elegir una historia con fuentes verificables.
4. Duplicar una plantilla de `content/templates/`.
5. Producir, revisar y publicar siguiendo `production/WORKFLOW.md`.

## Principios
- Precisión antes que velocidad.
- Análisis y narración originales; no copiar artículos ni retransmisiones.
- Separar hechos, opiniones, rumores y predicciones.
- Corregir públicamente errores materiales.
- No publicar datos sin fuente y fecha de consulta.

## Estado de la versión
**v1.0 — kit editorial inicial.** No incluye conexión automática a YouTube ni publicación automática.
